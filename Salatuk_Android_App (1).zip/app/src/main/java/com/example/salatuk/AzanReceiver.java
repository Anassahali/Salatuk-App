
package com.example.salatuk;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class AzanReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String prayerName = intent.getStringExtra("prayerName");
        Log.d("Salatuk", "Time for: " + prayerName);
        Intent serviceIntent = new Intent(context, AzanService.class);
        context.startForegroundService(serviceIntent);
    }
}
