
package com.example.salatuk;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import androidx.appcompat.app.AppCompatActivity;

import com.batoulapps.adhan.CalculationMethod;
import com.batoulapps.adhan.CalculationParameters;
import com.batoulapps.adhan.Coordinates;
import com.batoulapps.adhan.Madhab;
import com.batoulapps.adhan.PrayerTimes;
import com.batoulapps.adhan.data.DateComponents;
import com.batoulapps.adhan.data.Prayer;

import java.util.Calendar;
import java.util.EnumMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private void schedulePrayer(Prayer prayer, Calendar prayerTime) {
        Intent intent = new Intent(this, AzanReceiver.class);
        intent.putExtra("prayerName", prayer.name());
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, prayer.ordinal(), intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
        alarmManager.setExact(AlarmManager.RTC_WAKEUP, prayerTime.getTimeInMillis(), pendingIntent);
        Log.d("Salatuk", "Scheduled: " + prayer.name() + " at " + prayerTime.getTime());
    }

    private void scheduleAllPrayers() {
        Coordinates coordinates = new Coordinates(30.0444, 31.2357); // Cairo
        CalculationParameters params = CalculationMethod.EGYPTIAN.getParameters();
        params.madhab = Madhab.SHAFI;

        Calendar now = Calendar.getInstance();
        DateComponents date = DateComponents.from(now);
        PrayerTimes prayerTimes = new PrayerTimes(coordinates, date, params);

        Map<Prayer, Calendar> times = new EnumMap<>(Prayer.class);
        times.put(Prayer.FAJR, prayerTimes.fajr);
        times.put(Prayer.DHUHR, prayerTimes.dhuhr);
        times.put(Prayer.ASR, prayerTimes.asr);
        times.put(Prayer.MAGHRIB, prayerTimes.maghrib);
        times.put(Prayer.ISHA, prayerTimes.isha);

        for (Map.Entry<Prayer, Calendar> entry : times.entrySet()) {
            if (entry.getValue().after(now)) {
                schedulePrayer(entry.getKey(), entry.getValue());
            }
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel("azan_channel", "Azan Channel", NotificationManager.IMPORTANCE_HIGH);
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        createNotificationChannel();
        scheduleAllPrayers();
        finish();
    }
}
